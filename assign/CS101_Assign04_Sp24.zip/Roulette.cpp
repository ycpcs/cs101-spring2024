// CS101 Assignment 4 - Spring 2024
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

// TODO: Add function prototypes here

//////////////////////////
// DO NOT MODIFY main()!!!
// other than to uncomment
// function calls as you
// implement each function
//////////////////////////
int main() {	
	// Program variables
	//  account - total amount of money
	//  bet_type - type of bet user makes 1 - odd, 2 - even, 3 - number
	//  bet_amount - amount of money user wishes to bet
	//  wheel_spin - random number wheel lands on 0-37, 0 and 37 green slots
	//  number - user selected number if betting on number
	//  win_amount - amount user wins or loses for a given play
	
	double account = -1.0;
	int bet_type = 0;
	double bet_amount = 0.0;
	int wheel_spin = 0;
	int number = 0;
	double win_amount = 0.0;

	// Seed random number generator
	srand(time(0));
	
	// Get initial account amount - must be positive
	while (account <= 0) {
		printf("Enter the amount of money you are starting with: $ ");
		scanf("%lf", &account);
	}
	
	// Play until user quits or is out of money
	int keep_going = 1;
	while (keep_going == 1 && account > 0) {
		// Get user's bet type and number if betting on number (type 3)
		//bet_type = get_bet_type();
		printf("\n");
		if (bet_type == 3) {
			//number = get_number();
		}
		
		// Get user's bet amount
		//bet_amount = get_bet_amount(account);
		printf("\n");
		
		// Spin wheel and print result of spin
		//wheel_spin = spin_wheel();
		if (wheel_spin == 0 || wheel_spin == 37) {
			printf("The ball landed on a green slot.\n");
		} else {
			printf("The ball landed on %i.\n",wheel_spin);
		}
		
		// Determine win/loss amount
		//win_amount = evaluate_spin(wheel_spin, bet_amount, bet_type, number);
		
		// Update and print account
		account += win_amount;
		//print_account(account);
		
		// Determine if out of money or want to keep playing
		if (account <= 0.0) {
			printf("You are out of money.\n");
		} else {
			printf("Enter 0 to Quit: ");
			scanf("%i", &keep_going);
		}
	}
	printf("Thank you for playing Roulette.\n");
	
	return 0;
}

// TODO: Add function definitions here